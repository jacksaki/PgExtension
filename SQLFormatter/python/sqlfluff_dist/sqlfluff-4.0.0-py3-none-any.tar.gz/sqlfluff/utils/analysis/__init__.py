"""Code analysis tools to support development of more complex rules."""
